# 📊 Sales Performance Dashboard

## 🔍 Objective
Analyze sales trends, revenue growth, and regional performance.

## 🛠 Tools Used
- Power BI
- SQL
- Excel

## 📁 Files Included
- dataset.csv
- dashboard.pbix (placeholder)
- Project PDF

## 📊 Features
- KPIs tracking
- Regional analysis
- Category insights

## 💡 Insights
- Identify top regions and products
- Understand sales trends

## 📌 Conclusion
Supports data-driven business decisions.
